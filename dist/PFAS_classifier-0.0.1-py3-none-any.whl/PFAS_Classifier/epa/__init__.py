from .classify import EPA_2024_0

__all__ = (
    'EPA_2024_0'
)