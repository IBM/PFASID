from .classify import classify, CLASSIFICATION_METHODS,CLASSIFICATION_DATA,get_classifiers

__all__ = (
    'classify',
    'CLASSIFICATION_METHODS',
    'CLASSIFICATION_DATA',
    'get_classifiers',
)