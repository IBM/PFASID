from .classify import ECHA_2021_struct

__all__ = (
    'ECHA_2021_struct'
)