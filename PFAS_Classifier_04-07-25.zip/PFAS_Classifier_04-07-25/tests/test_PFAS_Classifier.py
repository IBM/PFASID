from pprint import pprint

from PFAS_Classifier.PFAS_Classifier import PFAS_Classifier

TEST_CONFIG = {
    "classification_methods": [
        "EPA_2023", "ECHA_2021_struct"
    ]
}

TEST_SMILES_LIST = [
    "CC(C(=O)O)c1ccc(C(F)(F)N(C)C)cc1",
    "CC(C)(C(F)(F)(F))(C(F)(F)(F))",
    "CC1=NC=C(COP(O)(O)=O)C(CN)=C1O"
]

def test_PFAS_Classifier() -> None:

    # TODO validate the results

    # init Classifier with data
    pprint(PFAS_Classifier().get_classification_info())
    print("-"*20)

    Classifier = PFAS_Classifier(TEST_CONFIG)
    pprint(Classifier.get_classification_info())
    print("-"*20)

    # run classification with parameters specified in data
    pprint(Classifier.classify(TEST_SMILES_LIST))
    print("-"*20)

    # changing classification method and re-running
    Classifier.classification_methods = ["Ontochem_2022"]
    pprint(Classifier.classify(TEST_SMILES_LIST))

    pprint(Classifier.config)
    pprint(Classifier.classification_methods)

    # as one-liner
    pprint(PFAS_Classifier(TEST_CONFIG).classify(TEST_SMILES_LIST))
    print("-"*20)