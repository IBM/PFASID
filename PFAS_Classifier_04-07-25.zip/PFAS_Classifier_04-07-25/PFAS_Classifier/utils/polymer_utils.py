#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from rdkit import Chem 
import re
import numpy as np

def rev_bonds(smi):
    mol = Chem.MolFromSmiles(smi)
    re_smi = Chem.MolToSmiles(mol, rootedAtAtom= mol.GetNumAtoms()-1)
    return re_smi  

def break_polymer(pSMILES):
    # break by semi colon
    data = pSMILES.split(';')
    # save connections by things without []
    connects = [i for i in data if '[' not in i]
    connects = [c.split('->') for c in connects]
    sections = [i for i in data if '[' in i]
    # for each section, split into monomers
    monomers = {}
    for sec in sections:
        # get the specific characters, replace with a weird thing, split on the weird thing
        str_output = re.sub('\[\*:\d+\]|\(\[\*:\d+\]\)', 'regex', sec)
        groups = str_output.split('regex')
        # find characters which describe connection points
        str_idx = [(m.span()[0], m.span()[1]) for m in re.finditer('\[\*:\d+\]|\(\[\*:\d+\]\)', sec)]
        # get connection points
        connect_points = [re.findall('\d+',sec[idx[0]:idx[1]+1])[0] for idx in str_idx]
        # append to monomers
        monomers.update({connect_points[c]:[groups[c],groups[c+1]] for c in range(len(connect_points))})
    #check and remove triple points
    monomers_filtered = {k:monomers[k] for k in monomers.keys() if monomers[k]!=['','']}
    connects_filtered = [c for c in connects if np.all([d in monomers_filtered.keys() for d in c])]
    return monomers_filtered, connects_filtered

# if there are 3 connection points in a row
def connect_monomers(monomers,connects):
    dual_monomers = []
    # make matches
    for c in connects:
        inside = f'({rev_bonds(monomers[c[1]][0])})({monomers[c[1]][1]})'
        if monomers[c[0]][0] == '' and monomers[c[0]][1] != '':
            outside = f'{monomers[c[0]][1][0]}{inside}{monomers[c[0]][1][1:]}'
        else:
            outside = f'{monomers[c[0]][0]}{inside}{monomers[c[0]][1]}'

        outside = outside.replace('()','')
        dual_monomers.append(outside)
    # set monomers
    dual_monomers = list(set(dual_monomers))
    # return list of dual monomers that will be checked
    return dual_monomers