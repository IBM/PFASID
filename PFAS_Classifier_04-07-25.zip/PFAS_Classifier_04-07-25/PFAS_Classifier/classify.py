#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

import multiprocessing
from typing import Union
from rdkit import Chem

from .classifiers.classifiers_index import CLASSIFICATION_METHODS
from .classifiers.classifiers_metadata import CLASSIFICATION_METADATA

def classify(
    smiles_list: list[str],
    classification_methods: list[str] = list(CLASSIFICATION_METHODS.keys()),
    multiprocess: bool = True
) -> dict[str, Union[list[str], dict[str, bool]]]:
    return classify_monomer(
        smiles_list=smiles_list, 
        classification_methods=classification_methods, 
        multiprocess=multiprocess
    )

def parse_classify_input(
        smiles_list: list[str], 
        classification_methods: list[str],
        filter_bad_smiles: bool = True
    ):
     # ensure correct types
    assert isinstance(
        smiles_list, list
    ), f"All smiles must be listed in as strings in the format list[str]." \
        f" You have given type {type(smiles_list)}"
    assert isinstance(
        classification_methods, list
    ), f"All methods must be listed in as strings in the format list[str]." \
        f" You have given type {type(classification_methods)}"
    
    if filter_bad_smiles:
        # check if smiles can be processed by rdkit
        good_smiles = []
        bad_smiles = []
        for smi in smiles_list:
            try:
                Chem.MolFromSmiles(smi)
                good_smiles.append(smi)
            except:
                bad_smiles.append(smi)
        return good_smiles, bad_smiles
    else:
        return smiles_list, []

def classify_monomer(
    smiles_list: list[str],
    classification_methods: list[str] = list(CLASSIFICATION_METHODS.keys()),
    multiprocess: bool = True,
) -> dict[str, Union[list[str], dict[str, bool]]]:
    result = {}
    
    good_smiles, bad_smiles = parse_classify_input(smiles_list, classification_methods)
    
    # run one method at a time, on all smiles with multi processing
    for method in classification_methods:
        classification_function = CLASSIFICATION_METHODS.get(method, None)
        if multiprocess == True:
            assert (
                classification_function is not None
            ), f"Classification method {method} not yet supported!"
            with multiprocessing.Pool() as pool:
                # apply function to all smiles
                multi_res = pool.map(classification_function, good_smiles)
                # format results
                result[method] = {
                    good_smiles[i]: multi_res[i] for i in range(len(good_smiles))
                }
        else:
            result[method] = {smi: classification_function(smi) for smi in good_smiles}
    
    # record bad smiles
    result["bad_smiles"] = bad_smiles
    
    return result

def get_classifiers():
    return CLASSIFICATION_METADATA
