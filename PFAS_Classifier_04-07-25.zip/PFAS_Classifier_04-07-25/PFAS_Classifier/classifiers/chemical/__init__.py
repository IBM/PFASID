#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from .classify import F_only

__all__ = "F_only"
