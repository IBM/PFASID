#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from .classify import *

__all__ = ("EPA_2021", "EPA_2023")
