from typing import Callable, Dict
from .echa.classify import ECHA_2021_struct
from .epa.classify import EPA_2023, EPA_2021
from .chemical.classify import F_only
from .ontochem.classify import ontochem_2022
from .OECD.classify import OECD_2021


CLASSIFICATION_METHODS: Dict[str, Callable] = {
    "ECHA_2021_struct": ECHA_2021_struct,
    # 'EPA_2021': EPA_2021,
    "contains_CF": F_only,
    "Ontochem_2022": ontochem_2022,
    "OECD_2021": OECD_2021,
    "EPA_2023": EPA_2023,
}
