#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from .classify import ECHA_2021_struct

__all__ = "ECHA_2021_struct"
