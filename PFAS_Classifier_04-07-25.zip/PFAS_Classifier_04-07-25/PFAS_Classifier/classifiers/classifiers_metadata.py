CLASSIFICATION_METADATA = {
    # 'EPA_2021':{
    #     "description":"",
    #     "reference": r"https://pubs.acs.org/doi/10.1021/cen-10040-polcon1"},
    "contains_CF": {
        "description": "At least one C-F bond in the molecule.",
        "reference": "Dan Sanders, PhD",
    },
    "EPA_2023": {
        "description": "Under the finalized rule, “PFAS” were defined as any chemical that includes at least one of the following three structures: (1) R-(CF2)-CF(R’)R’’, where both the CF2 and CF moieties are saturated carbons; (2) R-CF2OCF2-R’, where R and R’ can either be F, O, or saturated carbons; and (3) CF3C(CF3)R’R’’, where R’ and R’’ can either be F or saturated carbons.",
        "reference": r"https://www.epa.gov/system/files/documents/2023-09/prepublicationcopy_7902-02_fr-doc_aa_esignatureverified_2023-09-28.pdf",
    },
    "OntoChem_2022": {
        "description": "CF3C(CF3)RR’ where R and R' are any atom other than H. Or -(CF2)-CF- bonded to any atoms.",
        "reference": r"https://pubs.rsc.org/en/content/articlelanding/2022/dd/d2dd00019a",
    },
    "OECD_2021": {
        "description": "Contains −CF3 or −CF2− without a H/Cl/Br/I atom attached to it.",
        "reference": r"https://pubs.acs.org/doi/10.1021/acs.est.1c06896",
    },
    "ECHA_2021_struct": {
        "description": "er- and polyfluoroalkyl substances (PFASs) defined as: Any substance that contains at least one fully fluorinated methyl (CF3-) or methylene (-CF2-) carbon atom (without any H/Cl/Br/I attached to it). A substance that only contains the following structural elements is excluded from the scope of the proposed restriction: CF3-X or X-CF2-X’, where X = -OR or -NRR’ and X’ = methyl (-CH3), methylene (-CH2-), an aromatic group, a carbonyl group (-C(O)-), -OR’’, -SR’’ or –NR’’R’’’, and where R/R’/R’’/R’’’ is a hydrogen (-H), methyl (-CH3), methylene (-CH2-), an aromatic group or a carbonyl group (-C(O)-).",
        "reference": r"https://echa.europa.eu/de/registry-of-restriction-intentions/-/dislist/details/0b0236e18663449b",
    },
}