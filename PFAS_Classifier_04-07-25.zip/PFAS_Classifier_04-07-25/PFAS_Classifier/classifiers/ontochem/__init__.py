#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from .classify import ontochem_2022

__all__ = "ontochem_2022"
