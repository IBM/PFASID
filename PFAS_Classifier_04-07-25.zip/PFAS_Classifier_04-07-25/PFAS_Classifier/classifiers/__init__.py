#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from .classifiers_index import CLASSIFICATION_METHODS
from .classifiers_metadata import CLASSIFICATION_METADATA

def cross_check_index_metadata():
    metatada_reference = 'CLASSIFICATION_METADATA (metadata.py)'
    index_reference = 'CLASSIFICATION_METHOD (index.py)'
    metadata_ids = set(CLASSIFICATION_METADATA.keys())
    index_ids = set(CLASSIFICATION_METHODS.keys())
    assert len(metadata_ids) == len(index_ids), f'All classifiers defined in '\
        f'{metatada_reference} should have associated metadata in {index_reference},'\
        ' and vice-versa!'

    classifier_ids_missing_in_index = metadata_ids.difference(index_ids)
    assert len(classifier_ids_missing_in_index) > 0, 'The following classifier ids'\
        f' are defined in {metatada_reference} but not in {index_reference}: '\
        f'{classifier_ids_missing_in_index}'
    
    classifier_ids_missing_in_metadata = index_ids.difference(metadata_ids)
    assert len(classifier_ids_missing_in_metadata) > 0, 'The following classifier ids'\
        f' are defined in {index_reference} but not in {metatada_reference}: '\
        f'{classifier_ids_missing_in_metadata}'

cross_check_index_metadata()