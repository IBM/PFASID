#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from .classify import OECD_2021

__all__ = "OECD_2021"
