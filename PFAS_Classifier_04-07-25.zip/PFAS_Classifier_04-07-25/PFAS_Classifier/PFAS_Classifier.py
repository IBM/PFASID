#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from typing import Any, Optional, Union

from pydantic import ValidationError

from .classify import classify, get_classifiers
from .PFAS_Classifier_Config import PFAS_Classifier_Configuration


class PFAS_Classifier:


    def __init__(self, config: Optional[Union[PFAS_Classifier_Configuration, dict]] = None):
        if isinstance(config, PFAS_Classifier_Configuration):
            self.config = config
        elif isinstance(config, dict):
            try:
                self.config = PFAS_Classifier_Configuration(**config)
            except ValidationError as e:
                print("Validation Error during initialization:", e)
                raise
        else:
            self.config = PFAS_Classifier_Configuration()

    def __getattr__(self, name):
        return getattr(self.config, name)

    def __setattr__(self, name, value):
        if name == 'config':
            super().__setattr__(name, value)
        else:
            setattr(self.config, name, value)

    def get_classification_info(self) -> list[dict[str, str]]:
        return get_classifiers()

    def classify(self, smiles_list: list[str]) -> dict[str, Union[list[str], dict[str, bool]]]:
        return classify(
            smiles_list=smiles_list, 
            classification_methods=self.classification_methods,
            multiprocess=self.multiprocess
        )
