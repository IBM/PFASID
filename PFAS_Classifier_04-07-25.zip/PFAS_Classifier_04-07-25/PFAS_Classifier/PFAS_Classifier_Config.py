#
# Copyright IBM Corp. 2024 - 2024
# SPDX-License-Identifier: MIT
#

from typing import List, Optional

from pydantic import AfterValidator, BaseModel, Field
from typing_extensions import Annotated
from .classifiers.classifiers_index import CLASSIFICATION_METHODS

def check_classification_methods(methods: List[str]) -> List[str]:
    valid_classification_methods = list(CLASSIFICATION_METHODS.keys())
    for m in methods:
        if m not in valid_classification_methods:
            raise ValueError(
                f"Invalid classification method '{m}'. Valid: {', '.join(valid_classification_methods)}")
    return methods


class PFAS_Classifier_Configuration(BaseModel):
    classification_methods: Annotated[
        Optional[List[str]],
        Field(default_factory=list),
        AfterValidator(check_classification_methods)
    ]
    multiprocess: bool = False
