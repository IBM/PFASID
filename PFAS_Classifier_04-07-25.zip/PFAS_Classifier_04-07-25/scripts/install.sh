filepath=$1
installpath=$2
rm -f $installpath
mkdir $installpath
echo -n "Inform the ZIP Password:"
read -s zip_password
echo
unzip -P $zip_password $filepath -d $installpath  || exit 1

cd $installpath || exit 1

pip install -e . || exit 1
