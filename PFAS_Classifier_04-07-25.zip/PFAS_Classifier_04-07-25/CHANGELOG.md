# Changelog

All notable changes to this project will be documented in this file.

## [0.0.1] - 2024-10-11

- First version of the code
